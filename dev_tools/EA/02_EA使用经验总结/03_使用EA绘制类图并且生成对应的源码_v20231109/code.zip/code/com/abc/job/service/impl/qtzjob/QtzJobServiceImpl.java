package com.abc.job.service.impl.qtzjob;

import com.abc.job.service.qtzjob.QtzJobService;

/**
 * @author lipf
 * @version 1.0
 * @created 09-11��-2023 23:21:08
 */
public class QtzJobServiceImpl implements QtzJobService {

	public QtzJobServiceImpl(){

	}

	public void finalize() throws Throwable {

	}
}//end QtzJobServiceImpl