package com.abc.job.biz.impl.qtzjob;

import com.abc.job.biz.qtzjob.QtzJobBiz;

/**
 * @author lipf
 * @version 1.0
 * @created 09-11��-2023 23:21:08
 */
public class QtzJobImpl implements QtzJobBiz {

	public QtzJobImpl(){

	}

	public void finalize() throws Throwable {

	}
}//end QtzJobImpl