package com.abc.job.rest.qtzjob;


/**
 * @author lipf
 * @version 1.0
 * @created 09-11��-2023 23:21:08
 */
public class QtzRest {

	public QtzRest(){

	}

	public void finalize() throws Throwable {

	}
}//end QtzRest