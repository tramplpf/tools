package job΢�������ͼ���.com.abc.job.controller.qtzjob;


/**
 * @author lipf
 * @version 1.0
 * @created 09-11��-2023 23:06:13
 */
public class QtzJobController {

	public QtzJobController(){

	}

	public void finalize() throws Throwable {

	}
}//end QtzJobController