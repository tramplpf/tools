package com.abc.job.service.qtzjob;


/**
 * @author lipf
 * @version 1.0
 * @created 09-11��-2023 23:21:08
 */
public interface QtzJobService {

}